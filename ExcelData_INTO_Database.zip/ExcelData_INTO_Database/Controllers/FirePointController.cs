﻿
using Microsoft.AspNetCore.Mvc;
using ExcelData_INTO_Database.Data;
using ExcelData_INTO_Database.Models;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.IO;
using System.Text;
using ExcelData_INTO_Database.Models.Entities;

namespace ExcelData_INTO_Database.Controllers
{

    public class FirePointController : Controller
    {
        private readonly ApplicationDbContext dbContext;
        public FirePointController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public IActionResult Index()
        {
            return View();
        }

        
        [HttpPost]
        public IActionResult Add(IFormFile file)
        {
            if (file != null && file.Length > 0)
            {
                // Verify that the uploaded file is CSV
                if (Path.GetExtension(file.FileName).ToLower() == ".csv")
                {
                    List<AddFirePointViewModel> csvDataList = new List<AddFirePointViewModel>();

                    using (var reader = new StreamReader(file.OpenReadStream(), Encoding.UTF8))
                    {
                        // Skip the header row if needed
                         reader.ReadLine();

                        while (!reader.EndOfStream)
                        {
                            var line = reader.ReadLine();
                            var values = line.Split(',');

                            var fp= new FirePoint
                            {
                                Latitude = decimal.Parse(values[0]),
                                Longitude = decimal.Parse(values[1]),
                                Acq_date = values[2],
                                Day = int.Parse(values[3]),
                                Month = values[4],
                                Year = int.Parse(values[5])
                            };
                            

                            dbContext.FirePoints.Add(fp);
                            //dbContext.SaveChanges();
                            //AddFirePointViewModel csvData = new AddFirePointViewModel
                            //{
                            //    csvData.Latitude = values[0],
                            //    csvData.Longitude = values[1],
                            //    csvData.Acq_date = values[2],
                            //    csvData.Day = values[3],
                            //    csvData.month=values[4],
                            //    csvData.Year = values[5]
                            //};

                            //csvDataList.Add(csvData);
                        }
                    }
                    dbContext.SaveChanges();

                    // Now you have a list of CsvData objects (csvDataList)
                    // Store this data into your database table

                    // Example: storing into a hypothetical database context
                    //using (var db = new ApplicationDbContext())
                    //{
                    //    db.FirePoint.AddRange(csvDataList);
                    //    db.SaveChanges();
                    //}

                    ViewBag.Message = "File uploaded successfully";
                }
                else
                {
                    ViewBag.Message = "Invalid file format. Please upload a CSV file.";
                }
            }
            else
            {
                ViewBag.Message = "No file uploaded";
            }

            return View();
        }
    }
}
