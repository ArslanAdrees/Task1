﻿using ExcelData_INTO_Database.Models.Entities;
using Microsoft.EntityFrameworkCore;
namespace ExcelData_INTO_Database.Data
{
    public class ApplicationDbContext: DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options): base(options)
        {
                
        }

        public  DbSet<FirePoint> FirePoints { get; set; }
    }
}
