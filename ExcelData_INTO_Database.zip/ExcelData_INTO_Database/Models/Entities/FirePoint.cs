﻿using System.ComponentModel.DataAnnotations;
using System.Security.Principal;

namespace ExcelData_INTO_Database.Models.Entities
{
    public class FirePoint
    {
        [Key]
       public int Id {  get; set; }
        public decimal Longitude {  get; set; }
        public decimal Latitude { get; set; }
        public string Acq_date { get; set; }
        public int Day { get; set; }
        public string Month { get; set; }
        public int Year { get; set; }
      
    }
}
